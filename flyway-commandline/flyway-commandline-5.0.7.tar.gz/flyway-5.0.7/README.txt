Welcome to Flyway Trial Edition
-------------------------------
Database Migrations Made Easy


Documentation
-------------
You can find getting started guides and reference documentation at https://flywaydb.org


Sources
-------
Thank you for evaluating the Flyway Trial Edition. While we ship the Flyway sources
with the Flyway Pro Edition and the Flyway Enterprise Edition, we do not
ship any source code with the Trial Edition.

Should you need the sources for your evaluation, please contact us at sales@flywaydb.org


License
-------
See LICENSE.txt


Flyway is a registered trademark of Boxfuse GmbH.